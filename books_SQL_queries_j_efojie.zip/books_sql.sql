INSERT INTO users (first_name,last_name)
VALUES("Jane","Amsden"),("Emily","Dixon"),("Theodore","Dotsoevsky"),("William","Shapiro"),("Lao","Xiu");

INSERT INTO books (title)
VALUES("C sharp"),("Java"),("Python"),("PHP"),("Ruby");

UPDATE books
SET title = 'C#'
WHERE id = 1;

UPDATE users 
SET first_name = "Bill"
WHERE id = 4;

INSERT INTO favorite_books (user_id,book_id)
VALUES(1,1);

INSERT INTO favorite_books (user_id,book_id)
VALUES(1, 2), (2, 1), (2, 2), (2, 3), (3,1), (3,2), (3,3), (3,4), (4,1), (4,2), (4,3), (4,4), (4, 5);

SELECT id, first_name, last_name from users
JOIN favorite_books on users.id = favorite_books.user_id
WHERE favorite_books.book_id=3;

SET SQL_SAFE_UPDATES = 0;

DELETE FROM favorite_books
WHERE user_id = 2 AND book_id = 3;

INSERT INTO favorite_books (user_id,book_id)
VALUES(5,2);

SELECT * from books
JOIN favorite_books on  books.id = favorite_books.book_id
WHERE favorite_books.user_id = 3;

SELECT * from users
JOIN favorite_books on favorite_books.user_id = users.id
WHERE favorite_books.book_id = 5;